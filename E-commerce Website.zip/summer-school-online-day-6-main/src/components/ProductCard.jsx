import { Link } from "react-router-dom";
export default function ProductCard({ id, title, image, price }) {
  
  return (

    
    <Link to={`/products/${id}`} className="border rounded-xl p-4 shadow-md hover:shadow-lg transition">
      <img src={image} alt={title} className="h-48 w-full object-cover rounded" />
      <h2 className="mt-2 font-semibold text-lg">{title}</h2>
      <p className="text-blue-600 font-bold mt-1">₹{price}</p>
    </Link>
  );
}