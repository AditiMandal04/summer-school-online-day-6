import ProductCard from "../components/ProductCard";
import { products } from "../data/products";

export default function Home() {
  const featuredProducts = products.splice(0,13);
  return (
    <section className="p-6">
      <h1 className="text-3xl font-bold mb-4">Featured Products</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {featuredProducts.map((product) => (
          <ProductCard key={product.id} {...product} />
        ))}
      </div>
    </section>
  );
}