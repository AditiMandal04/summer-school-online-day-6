===========================================
🛒 E-Commerce React UI with TailwindCSS
===========================================

This project is a clean and modern React-based E-Commerce Frontend built with TailwindCSS. 
It includes routing, reusable components, and dummy product data (25 entries with real image links).
Ideal for beginners and intermediate developers learning React UI development.

-------------------------------------------
FEATURES
-------------------------------------------
- Homepage with featured products
- Product List page with all products
- Product Detail view using dynamic routes
- Cart Page (static for now)
- React Router v6 for page navigation
- Tailwind CSS for responsive and modern design
- Reusable components: Navbar, Footer, ProductCard
- Dummy data with 25 product entries including real image URLs

-------------------------------------------
GETTING STARTED
-------------------------------------------

1. Clone the repository:
   git clone https://github.com/your-username/ecommerce-react-ui.git
   cd ecommerce-react-ui

2. Install the dependencies:
   npm install

3. Start the development server:
   npm run dev

Then, open http://localhost:5173/ in your browser.

-------------------------------------------
FOLDER STRUCTURE
-------------------------------------------
src/
├── components/
│   ├── Footer.tsx
│   ├── Navbar.tsx
│   └── ProductCard.tsx
├── data/
│   └── products.ts
├── pages/
│   ├── Home.tsx
│   ├── Products.tsx
│   ├── ProductDetail.tsx
│   └── Cart.tsx
├── App.tsx
└── index.css

-------------------------------------------
TECHNOLOGIES USED
-------------------------------------------
- React 18+
- React Router v6
- TailwindCSS
- TypeScript (optional)



You can replace image URLs in src/data/products.ts with your own.

-------------------------------------------
FUTURE IMPROVEMENTS (TODO)
-------------------------------------------
- Implement cart functionality with useContext or Redux
- Add product filters and categories
- Enable search functionality
- Add checkout and payment integration
